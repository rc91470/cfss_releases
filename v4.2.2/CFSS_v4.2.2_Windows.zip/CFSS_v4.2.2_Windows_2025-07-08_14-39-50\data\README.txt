Place your circuit CSV files in this directory 
 
Required CSV format: 
- Circuit files should be named like: EB-DR.csv, CSW-RSW.csv, etc. 
- See documentation for detailed CSV format requirements 
