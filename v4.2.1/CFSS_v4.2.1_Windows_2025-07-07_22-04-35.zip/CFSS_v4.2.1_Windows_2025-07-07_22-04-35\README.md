# CFSS (Copper/Fiber Serial Scanner) - Private Development Repository

This is the **private development repository** for CFSS. This contains the source code, development tools, and internal documentation.

## 🔒 Repository Structure

This project now uses a **3-repository structure** for better organization and security:

### 1. **cfss_app** (Private - This Repository)
- **Purpose**: Source code and development
- **Contains**: Python source code, build scripts, dev tools
- **Access**: Private - development team only
- **Location**: `https://github.com/rc91470/cfss_app`

### 2. **cfss_releases** (Public)
- **Purpose**: Binary distribution and user support
- **Contains**: Compiled binaries, documentation, installation guides
- **Access**: Public - end users
- **Location**: `https://github.com/rc91470/cfss_releases`

### 3. **cfss_central_management** (Private)
- **Purpose**: Central management application
- **Contains**: Admin tools, server configurations
- **Access**: Private - admin team only

## 🚀 Development Workflow

### For Development
1. **Work in this repository** (cfss_app) for all code changes
2. **Test locally** using the development environment
3. **Build releases** using the build scripts
4. **Use the release automation** to push binaries to public repo

### For Releases
1. **Build** using `build_windows.bat` or `build_macos.sh`
2. **Run** the release automation script:
   ```powershell
   cd ..\cfss_releases
   ..\cfss_app\public_release_files\scripts\release_automation.ps1
   ```
3. **Review** the copied files in the public repository
4. **Create GitHub release** in the public repository

## 📁 Original Application Description

A cross-platform desktop application for scanning and verifying jumper cable serial numbers in network infrastructure. This tool helps network technicians ensure proper cable connections by comparing scanned serial numbers against expected values from circuit documentation.

## Platform Support

- **Windows 10/11**: Full support with native executable
- **macOS**: Compatible with macOS 10.14+ (Intel and Apple Silicon)
- **Cross-Platform**: Built with Python for maximum compatibility

## Features

### Core Functionality
- **Serial Number Verification**: Scan jumper cable serials and compare against expected values
- **Multiple Circuit Support**: Load and manage multiple network circuits from CSV files
- **Progress Tracking**: Visual progress bars showing completion percentage (matches only)
- **Persistent State**: Automatically saves and resumes scan progress across sessions

### User Interface
- **Modern Dark Theme**: Clean, professional interface built with CustomTkinter
- **Real-time Feedback**: Visual and audio feedback for matches, non-matches, and completion
- **Search Functionality**: Quickly jump to specific locations within circuits
- **Status Tracking**: Track matches, non-matches, and skipped items with reasons

### Data Management
- **CSV Import**: Import circuit data from CSV files with standardized column formats
- **Smart Sorting**: Intelligent sorting based on circuit type and jumper position
- **Deduplication**: Automatic removal of duplicate entries during import
- **Export Results**: Generate detailed text reports of scan results

### Audio Feedback
- **Cross-Platform Audio**: Uses pygame for reliable audio playback on all platforms
- **Match Sound**: Confirmation tone for successful matches
- **Non-Match Sound**: Alert tone for mismatches or issues  
- **Completion Sound**: Celebration tone when circuit is 100% complete

## Supported Circuit Types

- **Standard Circuits**: A-location to Z-location connections
- **CSW Circuits**: Special handling for CSW (Circuit Switch) configurations
- **Multi-Jumper Circuits**: Support for circuits with multiple jumper segments
- **Port-based Connections**: Handles various port numbering schemes (1, 2, 4, 7, etc.)

## Technical Specifications

### Requirements
- **Windows**: Windows 10/11, audio output device
- **macOS**: macOS 10.14+ (Mojave or later), audio output device
- **Development**: Python 3.8+ with required dependencies

### File Formats
- **Input**: CSV files with network circuit data
- **Output**: Text-based reports with tabular formatting
- **Database**: SQLite for persistent storage and state management

### Architecture
- **Modular Design**: Separate managers for data, circuits, and scan control
- **SQLite Backend**: Fast, reliable data storage and retrieval
- **Cross-Platform Audio**: Pygame mixer for consistent audio across platforms
- **Efficient Processing**: Hash-based change detection for fast CSV reloading

## Installation

### Windows
1. Download the latest Windows release (.exe) from the releases page
2. Extract to desired directory
3. Place CSV circuit files in the data folder
4. Run `cfss_app.exe`

### macOS
1. Download the latest macOS release (.app or .dmg) from the releases page
2. Install/extract to Applications folder or desired location
3. Place CSV circuit files in the data folder
4. Run the application (may need to allow in Security & Privacy settings)

### From Source (Both Platforms)
```bash
# Clone the repository
git clone [repository-url]
cd cfss_app

# Install dependencies
pip install -r requirements.txt

# Run the application
python cfss_app.py
```

## Usage

1. **Load Circuits**: Place CSV files in the data folder or use "Import CSV(s)"
2. **Select Circuit**: Choose from the circuit dropdown
3. **Select Jumper**: Choose which jumper segment to scan
4. **Scan Serials**: Use barcode scanner or manual entry
5. **Track Progress**: Monitor completion via progress bar and statistics
6. **Export Results**: Save scan results to text reports

## CSV Format Requirements

Your CSV files should include these columns:
- Length, A location, A device, A interface, A jumper serial
- Port 1-8 location, container, cassette, port, jumper serial
- Z location, Z device, Z interface, Z jumper serial

## Key Benefits

- **Cross-Platform**: Works on both Windows and macOS environments
- **Accuracy**: Eliminates human error in cable verification
- **Efficiency**: Faster than manual documentation methods  
- **Reliability**: Persistent state prevents data loss
- **Flexibility**: Handles various circuit types and configurations
- **Reporting**: Professional documentation for compliance and records

## Development

Built with Python using modern, cross-platform libraries:
- **CustomTkinter**: Modern UI framework (cross-platform)
- **SQLite**: Database management (built into Python)
- **Pygame**: Cross-platform audio system
- **Natural Sorting**: Intelligent data ordering

### Dependencies
```
customtkinter>=5.0.0
pygame>=2.0.0
natsort>=8.0.0
```

## Building from Source

### For Windows
```bash
pip install pyinstaller
pyinstaller --onefile --windowed cfss_app.py
```

### For macOS
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --osx-bundle-identifier com.yourcompany.cfss cfss_app.py
```

## 🛠️ Development Setup

### Prerequisites
- Python 3.11 or later
- Windows 10+ or macOS 10.15+
- Git with GitHub CLI (`gh`) configured

### Initial Setup
1. **Clone this repository**:
   ```bash
   git clone https://github.com/rc91470/cfss_app.git
   cd cfss_app
   ```

2. **Set up development environment**:
   ```bash
   # Windows
   setup_dev_windows.bat
   
   # macOS
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Start development server**:
   ```bash
   start_dev.bat  # Windows
   python cfss_app.py  # macOS/Linux
   ```

## 🔧 Build Process

### Windows Build
```bash
build_windows.bat
```

### macOS Build
```bash
chmod +x build_macos.sh
./build_macos.sh
```

### Release Process
1. **Build locally** using the appropriate build script
2. **Test the executable** thoroughly
3. **Run release automation**:
   ```powershell
   cd ..\cfss_releases
   ..\cfss_app\public_release_files\scripts\release_automation.ps1
   ```
4. **Create GitHub release** in the public repository

## 📚 Documentation

### Internal Documentation
- Development notes in source code
- API documentation in comments
- Build process documentation in scripts

### Public Documentation
- User guides in the **public repository** at `https://github.com/rc91470/cfss_releases`
- Installation instructions for end users
- Troubleshooting guides for support

## 🔐 Security Notes

- **Never commit** sensitive data (passwords, keys, tokens)
- **Use environment variables** for configuration
- **Review** all commits before pushing
- **Keep dependencies** updated and secure

---

## 📞 Internal Team Information

**Remember**: This is the private development repository. All public-facing content goes in the `cfss_releases` repository.

**Public Repository**: https://github.com/rc91470/cfss_releases
